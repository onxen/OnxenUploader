<img src="https://telegra.ph/file/efdf5689646da738eb787.jpg" alt="logo" target="/blank">

<h1 align="center">
 <b><a href="https://telegram.me/LazyDeveloper" target="/blank">BEWAFA Angel-Priya BOT</a></>
</h1>

<p align="center">🤍 Thanks for Being Here 🤍</p>


## * MiND iT....
👉 Only Auth Users (AUTH_USERS) Can Use The Bot

👉 Upload [YTDL Supported Links](https://ytdl-org.github.io/youtube-dl/supportedsites.html) to Telegram.

👉 Upload HTTP/HTTPS as File/Video to Telegram.

👉 Upload Mediafire, Zippyshare, Hxfile, Anonfiles, Antfiles URL using LK21


### ⚡️ Configs 

* `TG_BOT_TOKEN`  - Create a New BOT to Get bot token. follow link  https://telegram.me/BotFather

* `API_ID` - From my.telegram.org 

* `API_HASH` - From my.telegram.org 

* `AUTH_USERS`  - Your Telegram + Your your paid users id.
  - NOTE - Only `AUTH_USERS` can use this BOT. SO you must have to give your id.

* `LAZY_DEVELOPER` - Give ADMIN id in this field.

* `WEBHOOK` - Give value `LazyDev`.

* `DEF_THUMB_NAIL_VID_S` - default thumbnail to be used in the videos. Incase, youtube-dl is unable to find a thumbnail.

* `LOG_CHANNEL` - To keep an eye on the users. If they do upload something illegal.

  ### 📶 DEPLOYEMENT SUPPORT

<details><summary>🔥 Deploy To Koyeb 🔥</summary>
<p>
<br>                 
<a target="/blank" href="https://app.koyeb.com/deploy?type=git&repository=https://github.com/onxen/Uploader&branch=master&name=onxenuploder" >
  <img src="https://www.koyeb.com/static/images/deploy/button.svg" alt="Deploy">
</a>
</p>
</details>
<details><summary>🧡Deploy To Heroku🧡</summary>
<p>
<br>
<a href="https://heroku.com/deploy?template=https://github.com/LazyDeveloperr/Angel-Priya-Url-Uploader-bot">
  <img src="https://www.herokucdn.com/deploy/button.svg" alt="Deploy">
</a>
</p>
</details>


### 🔗 important_Links
- [❣️ Join Youtube](https://www.youtube.com/channel/UCY-iDra0x2hdd9PdHKcZkRw)


#### 🧡 Respecting Lazy... 🧡
- [🔥 LazyDeveloperr](https://github.com/LazyDeveloperr) 
- [🔥 Instagram](https://www.instagram.com/LazyDeveloperrr) 
- [🔥 Pyrogram](https://github.com/pyrogram/pyrogram)


**Features**:
👉 Upload [yt-dlp Supported Links](https://ytdl-org.github.io/youtube-dl/supportedsites.html) to Telegram.

🧡 Upload HTTP/HTTPS as File/Video to Telegram.

🧡 Upload zee5, sony.live, voot and much more.

🧡 Permanent thumbnail Support.

🧡 Broadcast message.

## Credits, and Thanks to
* [@LazyDeveloper](https://telegram.me/mRiderDM) LazyDeveloper
* [@SpEcHlDe](https://t.me/ThankTelegram) for his [AnyDLBot](https://telegram.dog/AnyDLBot)
* [Dan Tès](https://t.me/haskell) for his [Pyrogram Library](https://github.com/pyrogram/pyrogram)
* [Yoily](https://t.me/YoilyL) for his [UploaditBot](https://telegram.dog/UploaditBot)

#### LICENSE
- GPLv3
